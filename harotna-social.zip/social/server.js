// سيرفر بدون أي مكتبات خارجية - يعمل على Termux أو أي جهاز فيه Node.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data.json');
let db = { users: [], posts: [], sessions: {} };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) {}
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString('hex');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png' };

function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function body(req) {
  return new Promise(r => {
    let d = ''; req.on('data', c => { d += c; if (d.length > 3e6) req.destroy(); });
    req.on('end', () => { try { r(JSON.parse(d || '{}')); } catch (e) { r({}); } });
  });
}
const publicPost = (p, me) => ({
  id: p.id, user: p.user, text: p.text, image: p.image, time: p.time,
  likes: p.likes.length, liked: p.likes.includes(me), comments: p.comments
});

http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');

  if (url.pathname.startsWith('/api/')) {
    const me = db.sessions[(req.headers.authorization || '').replace('Bearer ', '')];
    const b = req.method === 'POST' ? await body(req) : {};
    const p = url.pathname;

    if (p === '/api/register') {
      const name = String(b.username || '').trim().slice(0, 20);
      if (name.length < 3 || String(b.password || '').length < 4) return send(res, 400, { error: 'الاسم 3 أحرف والكلمة 4 على الأقل' });
      if (db.users.find(u => u.name === name)) return send(res, 400, { error: 'الاسم مستخدم' });
      const salt = crypto.randomBytes(8).toString('hex');
      db.users.push({ name, salt, pass: hash(b.password, salt) });
    } else if (p === '/api/login') {
      const u = db.users.find(u => u.name === b.username);
      if (!u || u.pass !== hash(String(b.password || ''), u.salt)) return send(res, 401, { error: 'بيانات الدخول خاطئة' });
      const t = crypto.randomBytes(24).toString('hex'); db.sessions[t] = u.name;
      save(); return send(res, 200, { token: t, username: u.name });
    } else if (p === '/api/posts' && req.method === 'GET') {
      return send(res, 200, db.posts.slice().reverse().slice(0, 100).map(x => publicPost(x, me)));
    } else if (!me) {
      return send(res, 401, { error: 'سجّل الدخول أولاً' });
    } else if (p === '/api/posts') {
      const text = String(b.text || '').trim().slice(0, 500);
      if (!text && !b.image) return send(res, 400, { error: 'المنشور فارغ' });
      db.posts.push({ id: crypto.randomUUID(), user: me, text, image: b.image || '', time: Date.now(), likes: [], comments: [] });
    } else if (p.startsWith('/api/like/')) {
      const post = db.posts.find(x => x.id === p.split('/')[3]);
      if (post) { const i = post.likes.indexOf(me); i < 0 ? post.likes.push(me) : post.likes.splice(i, 1); }
    } else if (p.startsWith('/api/comment/')) {
      const post = db.posts.find(x => x.id === p.split('/')[3]);
      const text = String(b.text || '').trim().slice(0, 300);
      if (post && text) post.comments.push({ user: me, text, time: Date.now() });
    } else return send(res, 404, { error: 'غير موجود' });
    save(); return send(res, 200, { ok: true });
  }

  let f = path.join(__dirname, 'public', url.pathname === '/' ? 'index.html' : url.pathname);
  if (!f.startsWith(path.join(__dirname, 'public')) || !fs.existsSync(f)) f = path.join(__dirname, 'public', 'index.html');
  res.writeHead(200, { 'Content-Type': types[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
}).listen(PORT, '0.0.0.0', () => console.log('السيرفر يعمل على المنفذ ' + PORT));
