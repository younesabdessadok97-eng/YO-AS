# حارتنا - تطبيق تواصل اجتماعي (الهاتف هو السيرفر)

## 1) تشغيل السيرفر على هاتفك (Termux)
```
pkg update && pkg install nodejs git
git clone https://github.com/اسمك/اسم-المستودع
cd اسم-المستودع
node server.js
```
الموقع يعمل على: http://عنوان-هاتفك:3000
(عنوان الهاتف: اكتب `ifconfig` في Termux وابحث عن wlan0)

## 2) بناء APK
ارفع الملفات على GitHub ثم افتح تبويب Actions ثم Build APK ثم Run workflow.
بعد دقائق نزّل `harotna-apk` من أسفل صفحة التشغيل، وثبّت app-debug.apk.
افتح التطبيق، اضغط «السيرفر»، وأدخل http://عنوان-هاتفك:3000

## ملاحظات
- كل من على نفس الواي فاي يستطيع الاتصال. للإنترنت العام استخدم Cloudflare Tunnel أو Tailscale.
- البيانات تُحفظ في data.json.
